<div align="center">
<h1>ChatGPT UI</h1>
</div>

A ChatGPT web client that supports multiple users, multiple languages, and multiple database connections for persistent data storage.

The server of this project：[https://github.com/WongSaang/chatgpt-ui-server](https://github.com/WongSaang/chatgpt-ui-server)

## Documentation
- [English](https://wongsaang.github.io/chatgpt-ui/)
- [中文](https://wongsaang.github.io/chatgpt-ui/zh/)


https://user-images.githubusercontent.com/46235412/227156264-ca17ab17-999b-414f-ab06-3f75b5235bfe.mp4

