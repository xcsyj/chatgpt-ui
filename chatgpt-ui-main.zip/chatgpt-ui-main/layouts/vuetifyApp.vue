<template>
  <v-app
      :theme="$colorMode.value"
  >
    <slot />
  </v-app>
</template>